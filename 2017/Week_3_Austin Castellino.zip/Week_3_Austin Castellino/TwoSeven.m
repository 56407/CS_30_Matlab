%2.7E - Austin Castellino

%part a)
diary Diary_2_7.out
sum = 11 / 5 + 6;
disp(sum);
%8.2000

%part b)
sum = (11 / 5) + 6;
disp(sum);

%part c)
sum = 11 / (5 + 6);
disp(sum);

%part d)
sum = 3 ^ 2 ^ 3;
disp(sum);

%part e)
sum = 3 ^ (2 ^ 3);
disp(sum);

%part f)
sum = (3 ^ 2) ^ 3;
disp(sum);

%part g)
sum = (-11/5) + 6;
%w/o round: 3.8
disp(round(sum));

%part h)
sum = ceil(-11/5) + 6;
disp(sum);

%part i)
sum = floor((-11/5) + 6 );
disp(sum);

diary off