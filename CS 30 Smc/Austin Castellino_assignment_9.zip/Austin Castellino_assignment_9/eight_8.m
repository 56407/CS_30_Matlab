%8.8

t = [0:0.01:10]; %time variable

v = 10 * exp((-0.2 + 1i*pi)*t); %function

plot(v); %plot the function