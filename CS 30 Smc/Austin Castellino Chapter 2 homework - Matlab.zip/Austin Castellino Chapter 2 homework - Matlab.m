%Distance function - Matlab

%distance function
%input for the 1st point
temp = input ('Enter the 1st point like [2 4]\n');
x1=temp(1);
y1=temp(2);


%2nd point
temp = input('Enter 2nd point\n');
x2 = temp(1);
y2 = temp(2);


distance = sqrt((x1-x2)^2 + (y1-y2)^2);

display(distance);

%straight forward and easy to follow

%2_12

%Distance function - Matlab

%distance function
%input for the 1st point
temp = input ('Enter the 1st point like [2 4]\n');
x1=temp(1);
y1=temp(2);


%2nd point
temp = input('Enter 2nd point\n');
x2 = temp(1);
y2 = temp(2);


distance = sqrt((x1-x2)^2 + (y1-y2)^2);

display(distance);
%points to use [-3 2] and [3 -6]

%distance 3d function

%1st set of points
temp = input('Enter the 1st set of coordinates\n');

x1 = temp(1);
y1 = temp(2);
z1 = temp(3);

%2nd set of points

temp = input('Enter the 2nd set  of points\n');

x2 = temp(1);
y2 = temp(2);
z2 = temp(3);

distance = sqrt((x1 - x2)^2 + (y1 - y2)^2 + (z1 - z2)^2);
%points to use [-3 2 5] and [3 -6 -5]

display(distance);
diary('2_12');

% 2_18
%2.18 force to compress linear spring

%E = 1\2 * k * x^2;

% from the table
%the corresponding values
f = [20 30 25 20];

k= [200 250 300 400];


%calculates the compression of each spring

x=F/k;
fprintf('the compression of each spring');
display(x);

E = 0.5*k*x^2;
fprintf('\n Energy in each spring is: \n');

display(E);

fprintf('\n The total amount of energy is: \n');

display(max(E));
%the maximum amount of energy in the sppring.

%chapt2_19
%2.19 RLC circut

%working with 1/(2pisqrt(LC))

%calculate the resonant frequency

%L - inducttance
%C - capacity
%f0 - resonant freq

L = input('Enter the inductance L in henrys: ');

C = input('Enter capacity: ');
%use .25E-3 and .1E9

f0 = 1/(2*pi*sqrt(L*C));

fprintf('\n The resonant frequency of the circut is: %10.6f\n',f0);

%Chapt2.22
%skip parts C and E

%Calculate the tuning radius

%a -- centripetal accel
%v -- tangential velocity
%r -- turning radius

a = 2*9.81;
v = 0.85 * 340;
r = (v^2)/a;

display(r);
%display r

v = 1.5 * 340;
display(r);

%a = (v^2 \ r);

%Chapt2.22
%skip parts C and E

%Calculate the tuning radius

%a -- centripetal accel
%v -- tangential velocity
%r -- turning radius

a = 2*9.81;
v = 1.5 * 340;
r = (v^2)/a;

display(r); 
%display r;
%a = (v^2 \ r);
