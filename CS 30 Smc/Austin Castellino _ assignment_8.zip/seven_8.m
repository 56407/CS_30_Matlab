%7.8

%histograms 

%hist(y,nbins)
%creates and plots a histogram
%uses random set of Gaussian values

f = randn(10000, 1);

hist(f, 21);

%works perfectly