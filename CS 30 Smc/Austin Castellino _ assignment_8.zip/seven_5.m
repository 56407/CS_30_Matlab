%7.5

%anon function

fhandle = @(arglist)expr;

%plot the function 1/sqrt(x);

fplot(@(x)1/sqrt(x), [0.1 10]);

title('b/fplot of f(x) vs range');

grid on;

%straight froward




